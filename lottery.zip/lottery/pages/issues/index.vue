<template>
  <no-api />
</template>

<script>
import noApi from '~/docs/no-api.md'

export default {
  head(){
    return {
      title:'待实现API'
    }
  },
  scrollToTop: true,
  components:{
    noApi
  }
}
</script>
