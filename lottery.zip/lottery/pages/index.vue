<template>
  
</template>

<script>
  // import axios from 'axios'
  // import {mapGetters } from 'vuex'
  export default {
    name:'index',
    layout:'empty',
    // computed:{
    //   ...mapGetters([
    //     'username',
    //     'expires',
    //     'token'
    //   ]),
    //   ...mapGetters({
    //     bal:'pay/bal',
    //   })
    // }
  }
</script>
