export default {
  // 1min:'',
  bjpk10: '4001',
  cqssc: '1001',
  flb15: '1015',
  sd11x5: '2001',
  sh11x5: '2003',
  tjssc: '1007',
  txffc: '1005',
  xjssc: '1003',
  jskl3:false
}