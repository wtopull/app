// 奖励类型
export default [
  { id: 1, constant: 'PRIZE_TYPE_1', name: '固定值' },
  { id: 2, constant: 'PRIZE_TYPE_2', name: '销量百分比' },
  { id: 3, constant: 'PRIZE_TYPE_3', name: '亏损量百分比' },
]
