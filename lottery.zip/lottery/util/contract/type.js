export default [
  { id: 1, constant: 'CONTRACT_DAILY', name: '日契约' },
  { id: 2, constant: 'CONTRACT_WEEKLY', name: '周契约' },
  { id: 3, constant: 'CONTRACT_HALF_MONTH', name: '半月契约' },
  { id: 4, constant: 'CONTRACT_MONTH', name: '月契约' },
]
