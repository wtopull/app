export default {
  propError(prop) {
    return `prop ${prop} not exist in the row, please confirm wether the prop is right, this may cause unpredictable filter result`
  }
}
