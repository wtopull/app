(function () {
  function $_6(__1) {
    return $_4(_5a, __1);
  }

  function $_5(__1) {
    return $_4(_3Q, __1);
  }

  function $_4(__0, __1) {
    return {
      tool: __0,
      className: __1
    };
  }

  function $_3() {
    return $_0(_5a);
  }

  function $_2() {
    return $_0(_3Q);
  }

  function $_1() {
    return $_0(false);
  }

  function $_0(__0) {
    return {
      tool: __0
    };
  }

  var _2 = ["\u4E07\u4F4D", "\u5343\u4F4D", "\u767E\u4F4D", "\u5341\u4F4D", "\u4E2A\u4F4D"];
  var _8 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  var _1 = [_2, _8];
  var _k = ["\u7EC4\u9009120", _8];
  var _n = ["\u4E8C\u91CD\u53F7", "\u5355\u53F7"];
  var _m = [_n, _8];
  var _r = ["\u4E8C\u91CD\u53F7", "\u5355\u53F7"];
  var _q = [_r, _8];
  var _v = ["\u4E09\u91CD\u53F7", "\u5355\u53F7"];
  var _u = [_v, _8];
  var _z = ["\u4E09\u91CD\u53F7", "\u4E8C\u91CD\u53F7"];
  var _y = [_z, _8];
  var _D = ["\u56DB\u91CD\u53F7", "\u5355\u53F7"];
  var _C = [_D, _8];
  var _H = ["\u4E07\u4F4D", "\u5343\u4F4D", "\u767E\u4F4D", "\u5341\u4F4D"];
  var _G = [_H, _8];
  var _J = ["\u7EC4\u900924", _8];
  var _M = ["\u4E8C\u91CD\u53F7", "\u5355\u53F7"];
  var _L = [_M, _8];
  var _P = ["\u4E8C\u91CD\u53F7", _8];
  var _S = ["\u4E09\u91CD\u53F7", "\u5355\u53F7"];
  var _R = [_S, _8];
  var _W = ["\u5343\u4F4D", "\u767E\u4F4D", "\u5341\u4F4D", "\u4E2A\u4F4D"];
  var _V = [_W, _8];
  var _Y = ["\u7EC4\u900924", _8];
  var _11 = ["\u4E8C\u91CD\u53F7", "\u5355\u53F7"];
  var _10 = [_11, _8];
  var _14 = ["\u4E8C\u91CD\u53F7", _8];
  var _17 = ["\u4E09\u91CD\u53F7", "\u5355\u53F7"];
  var _16 = [_17, _8];
  var _1b = ["\u4E07\u4F4D", "\u5343\u4F4D", "\u767E\u4F4D"];
  var _1a = [_1b, _8];
  var _1d = ["\u5343\u4F4D", "\u767E\u4F4D", "\u5341\u4F4D"];
  var _1c = [_1d, _8];
  var _1f = ["\u767E\u4F4D", "\u5341\u4F4D", "\u4E2A\u4F4D"];
  var _1e = [_1f, _8];
  var _1j = ["\u7EC4\u4E09", _8];
  var _1l = ["\u7EC4\u4E09", _8];
  var _1n = ["\u7EC4\u4E09", _8];
  var _1p = ["\u7EC4\u516D", _8];
  var _1r = ["\u7EC4\u516D", _8];
  var _1t = ["\u7EC4\u516D", _8];
  var _1v = ["\u5C3E\u6570", _8];
  var _1x = ["\u5C3E\u6570", _8];
  var _1z = ["\u5C3E\u6570", _8];
  var _1D = ["\u8C79\u5B50"];

  var _1F = $_1();

  var _1B = ["\u7279\u6B8A\u53F7", _1D, _1F];
  var _1J = ["\u987A\u5B50"];

  var _1L = $_1();

  var _1H = ["\u7279\u6B8A\u53F7", _1J, _1L];
  var _1O = ["\u5BF9\u5B50"];

  var _1Q = $_1();

  var _1M = ["\u7279\u6B8A\u53F7", _1O, _1Q];
  var _1S = ["\u4E07\u4F4D", "\u5343\u4F4D"];
  var _1R = [_1S, _8];
  var _1V = ["\u5341\u4F4D", "\u4E2A\u4F4D"];
  var _1U = [_1V, _8];
  var _1X = ["\u524D\u4E8C\u7EC4\u9009", _8];
  var _20 = ["\u540E\u4E8C\u7EC4\u9009", _8];
  var _24 = ["\u4E07\u4F4D", "\u5343\u4F4D", "\u767E\u4F4D", "\u5341\u4F4D", "\u4E2A\u4F4D"];
  var _23 = [_24, _8];
  var _25 = ["\u4E0D\u5B9A\u4F4D", _8];
  var _28 = ["\u4E07\u4F4D", "\u5343\u4F4D", "\u767E\u4F4D"];
  var _29 = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11"];
  var _27 = [_28, _29];
  var _2m = ["\u5343\u4F4D", "\u767E\u4F4D", "\u5341\u4F4D"];
  var _2l = [_2m, _29];
  var _2o = ["\u767E\u4F4D", "\u5341\u4F4D", "\u4E2A\u4F4D"];
  var _2n = [_2o, _29];
  var _2v = ["\u524D\u4E09\u7EC4\u9009", _29];
  var _2x = ["\u4E2D\u4E09\u7EC4\u9009", _29];
  var _2z = ["\u540E\u4E09\u7EC4\u9009", _29];
  var _2C = ["\u4E07\u4F4D", "\u5343\u4F4D"];
  var _2B = [_2C, _29];
  var _2E = ["\u5341\u4F4D", "\u4E2A\u4F4D"];
  var _2D = [_2E, _29];
  var _2H = ["\u524D\u4E8C\u7EC4\u9009", _29];
  var _2J = ["\u540E\u4E8C\u7EC4\u9009", _29];
  var _2M = ["\u80C6\u7801", "\u62D6\u7801"];

  var _2Q = $_1();

  var _2P = [_2Q];
  var _2L = [_2M, _29, _2P];
  var _2R = ["\u524D\u4E09\u4F4D", _29];
  var _2T = ["\u4E2D\u4E09\u4F4D", _29];
  var _2V = ["\u540E\u4E09\u4F4D", _29];
  var _2Y = ["\u7B2C\u4E00\u540D", "\u7B2C\u4E8C\u540D", "\u7B2C\u4E09\u540D"];
  var _2X = [_2Y, _29];
  var _34 = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10"];
  var _32 = ["\u51A0\u519B", _34];
  var _3g = ["\u51A0\u519B", "\u4E9A\u519B"];
  var _3f = [_3g, _34];
  var _3l = ["\u51A0\u519B", "\u4E9A\u519B", "\u5B63\u519B"];
  var _3k = [_3l, _34];
  var _3q = ["\u7B2C\u516B\u540D", "\u7B2C\u4E5D\u540D", "\u7B2C\u5341\u540D"];
  var _3p = [_3q, _34];
  var _3x = ["\u7B2C\u4E00\u540D", "\u7B2C\u4E8C\u540D", "\u7B2C\u4E09\u540D", "\u7B2C\u56DB\u540D"];
  var _3w = [_3x, _34];
  var _3D = ["\u7B2C\u4E03\u540D", "\u7B2C\u516B\u540D", "\u7B2C\u4E5D\u540D", "\u7B2C\u5341\u540D"];
  var _3C = [_3D, _34];
  var _3M = ["\u5355", "\u53CC"];
  var _3Q = ["\u5168", "\u6E05"];

  var _3P = $_2();

  var _3K = ["\u548C\u503C\u5355\u53CC", _3M, _3P];
  var _3V = ["\u5927", "\u548C", "\u5C0F"];

  var _3Z = $_2();

  var _3T = ["\u548C\u503C\u5927\u5C0F", _3V, _3Z];
  var _42 = ["\u4E0A", "\u4E2D", "\u4E0B"];

  var _46 = $_2();

  var _40 = ["\u4E0A\u4E0B\u76D8", _42, _46];
  var _49 = ["\u5947", "\u548C", "\u5076"];

  var _4d = $_2();

  var _47 = ["\u5947\u5076\u76D8", _49, _4d];
  var _4g = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];
  var _4x = {
    className: "k3-hezhi"
  };
  var _4e = ["\u548C\u503C", _4g, _4x];
  var _4B = ["111", "222", "333", "444", "555", "666"];

  var _4I = $_5("dice3");

  var _4z = ["\u4E09\u540C\u53F7", _4B, _4I];
  var _4M = ["\u901A\u9009"];

  var _4O = $_1();

  var _4K = ["\u4E09\u540C\u53F7", _4M, _4O];
  var _4Q = ["\u540C\u53F7", "\u4E0D\u540C\u53F7"];
  var _4U = ["11", "22", "33", "44", "55", "66"];
  var _51 = [1, 2, 3, 4, 5, 6];
  var _4T = [_4U, _51];
  var _5a = ["\u6E05"];

  var _59 = $_6("dice2");

  var _5d = $_6("dice1");

  var _58 = [_59, _5d];
  var _4P = [_4Q, _4T, _58];
  var _5h = ["11", "22", "33", "44", "55", "66"];

  var _5o = $_5("dice2");

  var _5f = ["\u53F7\u7801", _5h, _5o];
  var _5s = [1, 2, 3, 4, 5, 6];

  var _5z = $_5("dice1");

  var _5q = ["\u53F7\u7801", _5s, _5z];
  var _5D = [1, 2, 3, 4, 5, 6];

  var _5K = $_5("dice1");

  var _5B = ["\u53F7\u7801", _5D, _5K];
  var _5O = ["\u5927", "\u5C0F"];

  var _5R = $_1();

  var _5M = ["\u53F7\u7801", _5O, _5R];
  var _5U = ["\u5355", "\u53CC"];

  var _5X = $_1();

  var _5S = ["\u53F7\u7801", _5U, _5X];
  var _5Z = ["\u4E00\u4E2D\u4E00", _29];
  var _62 = ["\u4E8C\u4E2D\u4E8C", _29];
  var _65 = ["\u4E09\u4E2D\u4E09", _29];
  var _68 = ["\u56DB\u4E2D\u56DB", _29];

  var _6c = $_3();

  var _6b = [_6c];
  var _6a = [_2M, _29, _6b];
  var _6e = ["\u4E94\u4E2D\u4E94", _29];

  var _6i = $_3();

  var _6h = [_6i];
  var _6g = [_2M, _29, _6h];
  var _6k = ["\u516D\u4E2D\u4E94", _29];

  var _6o = $_3();

  var _6n = [_6o];
  var _6m = [_2M, _29, _6n];
  var _6q = ["\u4E03\u4E2D\u4E94", _29];

  var _6u = $_3();

  var _6t = [_6u];
  var _6s = [_2M, _29, _6t];
  var _6w = ["\u516B\u4E2D\u4E94", _29];

  var _6A = $_3();

  var _6z = [_6A];
  var _6y = [_2M, _29, _6z];
  var _6C = ["\u4E0A", "\u4E0B"];
  var _6G = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40"];
  var _7l = ["41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "80"];
  var _6F = [_6G, _7l];

  var _81 = $_6("kl8-renxuan");

  var _83 = $_6("kl8-renxuan");

  var _80 = [_81, _83];
  var _6B = [_6C, _6F, _80];
  var _0 = {
    wuxing_zhixuan_fs: _1,
    wuxing_zhixuan_ds: 5,
    wuxing_zuxuan_120: _k,
    wuxing_zuxuan_60: _m,
    wuxing_zuxuan_30: _q,
    wuxing_zuxuan_20: _u,
    wuxing_zuxuan_10: _y,
    wuxing_zuxuan_5: _C,
    qiansi_zhixuan_fs: _G,
    qiansi_zhixuan_ds: 4,
    qiansi_zuxuan_24: _J,
    qiansi_zuxuan_12: _L,
    qiansi_zuxuan_6: _P,
    qiansi_zuxuan_4: _R,
    housi_zhixuan_fs: _V,
    housi_zhixuan_ds: 4,
    housi_zuxuan_24: _Y,
    housi_zuxuan_12: _10,
    housi_zuxuan_6: _14,
    housi_zuxuan_4: _16,
    qiansan_zhixuan_fs: _1a,
    zhongsan_zhixuan_fs: _1c,
    housan_zhixuan_fs: _1e,
    qiansan_zhixuan_ds: 3,
    zhongsan_zhixuan_ds: 3,
    housan_zhixuan_ds: 3,
    qiansan_zuxuan_zux3: _1j,
    zhongsan_zuxuan_zux3: _1l,
    housan_zuxuan_zux3: _1n,
    qiansan_zuxuan_zux6: _1p,
    zhongsan_zuxuan_zux6: _1r,
    housan_zuxuan_zux6: _1t,
    qiansan_qita_hezhiwz: _1v,
    zhongsan_qita_hezhiwz: _1x,
    housan_qita_hezhiwz: _1z,
    qiansan_qita_bz: _1B,
    zhongsan_qita_bz: _1B,
    housan_qita_bz: _1B,
    qiansan_qita_sz: _1H,
    zhongsan_qita_sz: _1H,
    housan_qita_sz: _1H,
    qiansan_qita_dz: _1M,
    zhongsan_qita_dz: _1M,
    housan_qita_dz: _1M,
    erxing_zhixuan_qianerfs: _1R,
    erxing_zhixuan_qianerds: 2,
    erxing_zhixuan_houerfs: _1U,
    erxing_zhixuan_houerds: 2,
    erxing_zuxuan_qianerzxfs: _1X,
    erxing_zuxuan_qianerzxds: 2,
    erxing_zuxuan_houerzxfs: _20,
    erxing_zuxuan_houerzxds: 2,
    dingweidan_dingweidan_dwq: _23,
    budingwei_sanxingbudingwei_qiansanyimabdw: _25,
    budingwei_sanxingbudingwei_qiansanermabdw: _25,
    budingwei_sanxingbudingwei_zhongsanyimabdw: _25,
    budingwei_sanxingbudingwei_housanyimabdw: _25,
    budingwei_sixingbudingwei_qiansiyimabdw: _25,
    budingwei_sixingbudingwei_qiansiermabdw: _25,
    budingwei_wuxingbudingwei_wuxingyimabdw: _25,
    budingwei_wuxingbudingwei_wuxingermabdw: _25,
    budingwei_wuxingbudingwei_wuxingsanmabdw: _25,
    sanma_zhixuan_qiansanzhixuanfs: _27,
    sanma_zhixuan_zhongsanzhixuanfs: _2l,
    sanma_zhixuan_housanzhixuanfs: _2n,
    sanma_zhixuan_qiansanzhixuands: 8,
    sanma_zhixuan_zhongsanzhixuands: 8,
    sanma_zhixuan_housanzhixuands: 8,
    sanma_zuxuan_qiansanzuxuands: 8,
    sanma_zuxuan_zhongsanzuxuands: 8,
    sanma_zuxuan_housanzuxuands: 8,
    sanma_zuxuan_qiansanzuxuanfs: _2v,
    sanma_zuxuan_zhongsanzuxuanfs: _2x,
    sanma_zuxuan_housanzuxuanfs: _2z,
    erma_zhixuan_qianerzhixuanfs: _2B,
    erma_zhixuan_houerzhixuanfs: _2D,
    erma_zhixuan_qianerzhixuands: 5,
    erma_zhixuan_houerzhixuands: 5,
    erma_zuxuan_qianerzuxuanfs: _2H,
    erma_zuxuan_houerzuxuanfs: _2J,
    erma_zuxuan_qianerzuxuandt: _2L,
    erma_zuxuan_houerzuxuandt: _2L,
    budingwei_budingwei_qiansanbdw: _2R,
    budingwei_budingwei_zhongsanbdw: _2T,
    budingwei_budingwei_housanbdw: _2V,
    dingweidan_dingweidan_dwd: _2X,
    yixing_qianyi_fs: _32,
    erxing_qianer_fs: _3f,
    erxing_qianer_ds: 5,
    sanxing_qiansan_fs: _3k,
    sanxing_housan_fs: _3p,
    sanxing_qiansan_ds: 8,
    sanxing_housan_ds: 8,
    sixing_qiansi_fs: _3w,
    sixing_housi_fs: _3C,
    sixing_qiansi_ds: 11,
    sixing_housi_ds: 11,
    quwei_quwei_ds: _3K,
    quwei_quwei_dx: _3T,
    quwei_quwei_sx: _40,
    quwei_quwei_jo: _47,
    hezhi_hezhi_hz: _4e,
    santonghao_santonghao_sthdx: _4z,
    santonghao_santonghao_sthtx: _4K,
    ertonghao_ertonghao_ethdx: _4P,
    ertonghao_ertonghao_ethfx: _5f,
    sanbutonghao_sanbutonghao_sbthds: _5q,
    erbutonghao_erbutonghao_ebth: _5B,
    daxiaodanshuang_daxiao_dx: _5M,
    daxiaodanshuang_danshuang_ds: _5S,
    renxuan_renxuands_ds1z1: 2,
    renxuan_renxuanfs_fs1z1: _5Z,
    renxuan_renxuands_ds2z2: 5,
    renxuan_renxuanfs_fs2z2: _62,
    dantuo_dantuo_dt2z2: _2L,
    renxuan_renxuands_ds3z3: 8,
    renxuan_renxuanfs_fs3z3: _65,
    dantuo_dantuo_dt3z3: _2L,
    renxuan_renxuands_ds4z4: 11,
    renxuan_renxuanfs_fs4z4: _68,
    dantuo_dantuo_dt4z4: _6a,
    renxuan_renxuands_ds5z5: 14,
    renxuan_renxuanfs_fs5z5: _6e,
    dantuo_dantuo_dt5z5: _6g,
    renxuan_renxuands_ds6z5: 17,
    renxuan_renxuanfs_fs6z5: _6k,
    dantuo_dantuo_dt6z5: _6m,
    renxuan_renxuands_ds7z5: 20,
    renxuan_renxuanfs_fs7z5: _6q,
    dantuo_dantuo_dt7z5: _6s,
    renxuan_renxuands_ds8z5: 23,
    renxuan_renxuanfs_fs8z5: _6w,
    dantuo_dantuo_dt8z5: _6y,
    renxuan_renxuan_rx1: _6B,
    renxuan_renxuan_rx2: _6B,
    renxuan_renxuan_rx3: _6B,
    renxuan_renxuan_rx4: _6B,
    renxuan_renxuan_rx5: _6B,
    renxuan_renxuan_rx6: _6B,
    renxuan_renxuan_rx7: _6B
  };
  module.exports = _0;
})();