require('source-map-support/register')
module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("express");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("webpack");

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_express__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_express___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_express__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_nuxt__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_nuxt___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_nuxt__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__api__ = __webpack_require__(4);



const app = __WEBPACK_IMPORTED_MODULE_0_express___default()();
const bodyParser = __webpack_require__(6);
// const session = require('express-session')
const host = process.env.HOST || __webpack_require__(7);

var proxyMiddleware = __webpack_require__(9);

/*
  don't use process.env.PORT in package.json PORT=3100
  .nuxt axios (process.env.API_URL || 'http://localhost:3200/api') will use npm_package_config_nuxt_port
  it dispkay server connect ECONNREFUSED 127.0.0.1:3200  when f5 refresh home page on pm2 server
*/
const port = process.env.npm_package_config_nuxt_port || 3100;

app.set('port', port);
// app.disable('x-powered-by')
// can't app.set('x-powered-by','xxx')
app.use(function (req, res, next) {
  res.setHeader('X-Powered-By', 'caishi');
  next();
});

// app.use(bodyParser.json({limit:'900kb'}))
app.use(bodyParser.urlencoded({ extended: false }));

// app.use(session({
//   secret: 'super-secret-key',
//   resave: false,
//   saveUninitialized: false,
//   cookie: { maxAge: 60000 * 60 * 24}
// }))

// Import API Routes
app.use('/api', __WEBPACK_IMPORTED_MODULE_2__api__["a" /* default */]);

// Import and Set Nuxt.js options
let config = __webpack_require__(10);
config.dev = !("development" === 'production');

// Init Nuxt.js
const nuxt = new __WEBPACK_IMPORTED_MODULE_1_nuxt__["Nuxt"](config);

// Build only in dev mode
if (config.dev) {
  const builder = new __WEBPACK_IMPORTED_MODULE_1_nuxt__["Builder"](nuxt);
  builder.build().catch(error => {
    console.error(error);
    process.exit(1);
  });
}

// app.use(proxyMiddleware({
//   '/api/': {
//     target: 'http://alpha-api.test.bestsnake.com',
//     onProxyReq(proxyReq, req, res) {
//       proxyReq.setHeader('DeviceType', 1)
//       proxyReq.setHeader('Authorization', token.access_token)
//     }
//   },
//   '/sys-report/': {
//     target: 'http://lottery-detection-center.test.bestsnake.com'
//   }
// }))

// Give nuxt middleware to express
app.use(nuxt.render);

// Listen the server
app.listen(port, host);
console.log('Server listening on ' + host + ':' + port); // eslint-disable-line no-console
// if(!config.dev){
//   require('localtunnel')(port, {local_host:host,subdomain:require('../package').name},function(err, tunnel) {
//     if (err) {
//       return console.log(err)
//     }
//     console.log(`localtunnel ${tunnel.url}`)
//   })
// }


__webpack_require__(24)(`http://${host}:${port}`);

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("nuxt");

/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_express__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_express___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_express__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__auth__ = __webpack_require__(5);



// import sessions from './sessions'

const router = Object(__WEBPACK_IMPORTED_MODULE_0_express__["Router"])();
const app = __WEBPACK_IMPORTED_MODULE_0_express___default()();
// router.use((req, res, next) => {
//   Object.setPrototypeOf(req, app.request)
//   Object.setPrototypeOf(res, app.response)
//   req.res = res
//   res.req = req
//   next()
// })

router.use(__WEBPACK_IMPORTED_MODULE_1__auth__["a" /* default */]);
// router.use(sessions)

/* harmony default export */ __webpack_exports__["a"] = (router);

/***/ }),
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_express__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_express___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_express__);

// import axios from 'axios'
// import {oauthParms,HOST,baseURL} from '../../build/api-config'
const router = Object(__WEBPACK_IMPORTED_MODULE_0_express__["Router"])();

router.get('/init', function (req, res, next) {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  // axios.post(`${HOST}/oauth/token`,oauthParms)
  // .then(({data:{access_token}}) => {
  //   res.json({access_token,ip})
  // })
  res.json({ ip });
});

router.get('/doc_enter', function (req, res, next) {
  // if (req.body.pw === 'a123newtopsky321') {
  if (req.query.pw === 'a123newtopsky321') {
    return res.json({ success: 'heihei123' });
  }
  res.json({ error: 1, message: '密码错误！请联系管理员' });
});

router.get('/doc_auth', function (req, res, next) {
  if (req.query.pw === 'heihei123') {
    return res.send(true);
  }
});

router.get('/ui_doc_enter', function (req, res, next) {
  if (req.query.pw === 'a123456') {
    return res.json({ success: 'haha123' });
  }
  res.json({ error: 1, message: '密码错误！请联系管理员' });
});

router.get('/ui_doc_auth', function (req, res, next) {
  if (req.query.pw === 'haha123') {
    return res.send(true);
  }
});

/* harmony default export */ __webpack_exports__["a"] = (router);

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("body-parser");

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

const getIp = () => {

  var networkInterfaces = __webpack_require__(8).networkInterfaces();
  var matches = [];

  Object.keys(networkInterfaces).forEach(function (item) {
    networkInterfaces[item].forEach(function (address) {
      if (address.internal === false && address.family === "IPv4") {
        matches.push(address.address);
      }
    });
  });

  return matches[0];
}

module.exports = getIp()

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("os");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("http-proxy-middleware");

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

// const path = require('path')
const webpack = __webpack_require__(1);
const LodashModuleReplacementPlugin = __webpack_require__(11);
const _ = __webpack_require__(12);
const pkg = __webpack_require__(13);
const token = __webpack_require__(14);
// const markdown = require('./build/markdown')
const NODE_ENV = "development";
const isDev = NODE_ENV === 'development';
// const isProd = NODE_ENV === 'production'
const extend = __webpack_require__(15);
const router = __webpack_require__(23);
let modules = ['@nuxtjs/axios', ['@nuxtjs/component-cache', { maxAge: 1000 * 60 * 60 }]].concat(isDev ? [] : [['@nuxtjs/pwa']]);

let build = {
  //npm run build --analyze
  //todo https://github.com/samccone/bundle-buddy
  analyze: process.env.npm_config_analyze ? { analyzerMode: 'static' } : false,
  publicPath: '/.nuxt/dist/',
  plugins: [new LodashModuleReplacementPlugin({
    shorthands: true, //gzip 8.5k -> 10.08k
    collections: true,
    currying: true
  }), new webpack.ProvidePlugin({
    $: 'jquery/dist/jquery.custom.js',
    jQuery: 'jquery/dist/jquery.custom.js'
  })],
  babel: {
    plugins: ['lodash', 'date-fns', 'jsx-vue-functional', ['component', [{
      libraryName: 'element-ui',
      styleLibraryName: '~assets/element-theme'
      // "styleLibraryName": "theme-chalk"
    }]]],
    presets: [['vue-app', {
      targets: isDev ? { chrome: 66 } : { ie: 10 }
    }]]
  },
  extend,
  extractCSS: !isDev,
  filenames: {
    chunk: `[${isDev ? 'name' : 'id'}].[chunkhash].js`
  },
  vendor: ['jquery/dist/jquery.custom.js'],
  // You cannot use ~/ or @/ here since it's a Webpack plugin
  styleResources: {
    scss: ['./assets/element-variables.scss', './assets/scss/variables.scss']
  }
  //element-ui still has duplicates Selectors,http://cssnano.co/optimisations/uniqueselectors/
  //use postcss-cli resolve
  // if(!isDev) {
  //   build.postcss = require('./build/postcss.config')
  // }

};module.exports = {
  /*
   ** Headers of the page
   */
  head: {
    title: 'Caishi Recreation',
    meta: [{ charset: 'utf-8' }, {
      name: 'viewport',
      content: 'width=device-width, initial-scale=1, shrink-to-fit=no'
    }, { 'http-equiv': 'X-UA-Compatible', content: 'IE=edge' }, { name: 'renderer', content: 'webkit' }, { hid: 'description', name: 'description', content: 'Caishi Recreation' }, { name: 'google', value: 'notranslate' }],
    link: [{ rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }],
    script: [{ src: '/iconfont.js', body: true }]
  },
  /*
   ** Customize the progress bar color
   */
  loading: { color: '#e48633' },
  // <yt-page-navigation-progress aria-valuemin="0" aria-valuemax="100" id="" class="style-scope ytd-app" aria-valuenow="19">
  //   <div id="progress" class="style-scope yt-page-navigation-progress" style="transform: scaleX(0.19);"></div>
  // </yt-page-navigation-progress>
  //foreground & background

  // loadingIndicator: {
  //   name: 'rectangle-bounce',
  //   color: 'white',
  //   background: '#e48633'
  // },
  css: [{ src: '~assets/scss/index.scss', lang: 'scss' }, '~assets/c8css/common.css'],
  // layoutTransition: {
  //   name: 'page',
  //   mode: 'out-in'
  // },
  build,
  env: {
    appVersion: pkg.version,
    loginName: process.env.npm_config_name,
    loginPassword: process.env.npm_config_pw,
    fixVersion: process.env.npm_config_fix_version
  },
  manifest: {
    name: 'caishi',
    description: 'Caishi Recreation',
    theme_color: '#f7d453'
  },
  modules,

  // serverMiddleware:[
  //   // { path: '/api-front', handler: '~/server/auth.js' }
  //   '~/server/auth.js'
  // ],
  axios: {
    prefix: '/api',
    proxy: true,
    progress: false //requests is too more
  },
  proxy: [[process.env.npm_package_config_api_host, {
    onProxyReq(proxyReq, req, res) {
      proxyReq.setHeader('DeviceType', 1);
      proxyReq.setHeader('Authorization', token.access_token);
    }
  }], 'http://lottery-detection-center.test.bestsnake.com/sys-report'],
  plugins: ['~/plugins/vuex-router-sync', { src: '~/plugins/vuex-persistedstate', ssr: false }, '~/plugins/token', '~/plugins/filters', '~/plugins/mixin', '~/plugins/common', '~/plugins/ajax'],
  router,
  render: {
    resourceHints: false,
    // gzip: isDev ? {threshold: 0} : {level:9},
    bundleRenderer: {
      // https://ssr.vuejs.org/en/api.html#shouldpreload
      // this option fail
      // shouldPreload: (file, type) => {
      //   return file.includes('play-help')
      // }
    }
  },
  // ErrorPage:'~/components/ErrorPage',
  messages: {
    error_404: '查无此页！',
    // node_modules\nuxt\lib\app\components\nuxt-error.vue
    // client_error_details:'系统错误，请联系客服。',
    // client_error:'系统错误',
    nuxtjs: ''
  },
  debug: process.env.DEBUG
};

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("lodash-webpack-plugin");

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = {"name":"caishi","version":"1.0.0","description":"caishi","author":"Wu Ming","private":true,"scripts":{"nuxt":"node build/nuxt","copy:files":"node build/copy","static:json":"rimraf assets/config && node build/get-static & node build/get-plays","static:plays":"node build/get-plays","static:fix":"npm run static:json --fix_version=fix","custom:jquery":"node build/jquery-custom","dev:opn":"cross-env NODE_ENV=development npm run nuxt","dev":"backpack dev","dev:fix":"npm run dev --fix_version=fix","build":"nuxt build","build:source-map":"cross-env SOURCE_MAP=true nuxt build","start":"nuxt start","start:backpack":"cross-env NODE_ENV=production DEBUG=true node backpack_output/caishi","backpack":"backpack build","build:prod":"run-s clean build nuxt","build:express":"cross-env DEBUG=true run-s clean build copy:files postcss backpack start:backpack","dev-spa":"nuxt dev --spa","build-spa":"nuxt build --spa","start-spa":"nuxt start --spa","postcss":"postcss -c build -r .nuxt/dist/*.css","clean":"rimraf .nuxt/dist dist","generate":"nuxt generate","lint":"eslint --ext .js,.vue --ignore-path .gitignore .","precommit":"npm run lint","element-theme":"et","sentry:upload":"sentry-cli releases -o noop -p alpha files %npm_package_version% upload-sourcemaps --url-prefix ~/_nuxt .nuxt/dist","sentry":"run-s clean build:source-map sentry:upload","serve:pm2":"cross-env PORT=3100 HOST=127.0.0.1 pm2 start backpack_output/caishi.js","serve:build":"run-s clean build copy:json backpack serve:pm2","postinstall":"npm run custom:jquery","changelog":"conventional-changelog -p angular -i CHANGELOG.md -s"},"config":{"nuxt_port":"3100","api_host":"http://alpha-api.test.bestsnake.com/api","commitizen":{"path":"./node_modules/cz-conventional-changelog"}},"dependencies":{"@nuxtjs/axios":"5.0.1","@nuxtjs/component-cache":"^1.1.1","@nuxtjs/pwa":"^2.0.5","@xkeshi/vue-countdown":"^0.5.0","animejs":"^2.2.0","bootstrap":"^4.0.0","clipboard":"^1.7.1","crypto-js":"^3.1.9-1","date-fns":"^1.29.0","echarts":"^4.0.4","element-ui":"^2.2.0","github-markdown-css":"^2.10.0","highlight.js":"^9.12.0","jquery":"^3.3.1","js-combinatorics":"^0.5.3","markdown-it-anchor":"^4.0.0","marquee3000":"^1.0.9","moveto":"^1.7.1","number-precision":"^1.2.0","nuxt":"1.3.0","particles.js":"^2.0.0","push.js":"^1.0.5","qrcode":"^1.2.0","raven-js":"^3.22.4","superagent":"^3.8.2","ua-parser-js":"^0.7.17","vue-data-tables":"^3.1.3","vue-lazyload":"^1.2.1","vuex-persistedstate":"^2.4.2","vuex-router-sync":"^5.0.0"},"devDependencies":{"@nuxtjs/proxy":"1.1.4","babel-eslint":"^8.2.2","babel-plugin-component":"^1.1.0","babel-plugin-date-fns":"^0.1.0","babel-plugin-jsx-vue-functional":"^2.1.0","babel-plugin-lodash":"^3.3.2","babel-plugin-transform-optional-chaining":"^7.0.0-beta.3","backpack-core":"^0.5.0","conventional-changelog-cli":"^1.3.15","cross-env":"^5.1.3","cz-conventional-changelog":"^2.1.0","element-theme":"^2.0.1","element-theme-chalk":"^2.2.0","eslint":"^4.18.1","eslint-config-standard":"^11.0.0","eslint-loader":"^2.0.0","eslint-plugin-html":"^4.0.2","eslint-plugin-import":"^2.9.0","eslint-plugin-node":"^6.0.1","eslint-plugin-promise":"^3.6.0","eslint-plugin-standard":"^3.0.1","express-session":"^1.15.6","localtunnel":"^1.8.3","lodash-webpack-plugin":"^0.11.4","markdown-it-attrs":"^1.2.1","node-sass":"^4.7.2","npm-run-all":"^4.1.2","postcss-cli":"^5.0.0","preload-webpack-plugin":"^2.2.0","prepack":"^0.2.23","rimraf":"^2.6.2","sass-loader":"^6.0.6","sentry-cli-binary":"^1.25.0","transliteration":"^1.6.2","vue-markdown-loader":"^2.3.0","webpack-monitor":"^1.0.14"},"browserslist":["Chrome >= 45","Firefox ESR","Edge >= 12","Explorer >= 10","iOS >= 9","Safari >= 9","Android >= 4.4","Opera >= 30"],"element-theme":{"browsers":["ie >= 10"],"out":"./assets/element-theme","config":"./assets/element-variables.scss","theme":"element-theme-chalk","minimize":false}}

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = {"version":1522928271,"access_token":"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImU3OGYxODZiZGJkOTAzYzJkYmJmYjYyN2NlNzU3MzZjMzllMzMwN2Y5ZTEyNDgxMWZlODM1ZTlmNzUyM2RhM2FiMTM5Yzg3NGQwYTlhMzk1In0.eyJhdWQiOiIzIiwianRpIjoiZTc4ZjE4NmJkYmQ5MDNjMmRiYmZiNjI3Y2U3NTczNmMzOWUzMzA3ZjllMTI0ODExZmU4MzVlOWY3NTIzZGEzYWIxMzljODc0ZDBhOWEzOTUiLCJpYXQiOjE1MjMxMTA0NjQsIm5iZiI6MTUyMzExMDQ2NCwiZXhwIjoxNTU0NjQ2NDY0LCJzdWIiOiIyIiwic2NvcGVzIjpbXX0.LqgXDV3rnW0XfukXcraVGiQMKr2cOsFg7lBw7OKGO5sySt_HthX1Jjc-Mg1NUUc8D8EscOrw8-BQChNvYOhHDB6G2cJN8CHjXfK0c_FZzk6eNN5pVARDv59kJdqPBXsArEJZjwQH38LeO69FwY8Oj0lRT0qP3tW3WbHFk1fZAiVvT5eKXZ-7342anHRRYfo0EgleUUUHCRDhJvvr81kSX4M7KjZtmfYfIdL7rIl5ILhcSsXd1BCuOzhSq-68kyW1LjRp72Ccj9t8QDQsSe9X7-y7rV1qrPKGO5icLTurnCvwhrWPxVdmsdGuchH8qUQw-rXgna_TRbi44rDbdajVUuxryI9tHHmOjsD24DFW4WJarqgZeAx7lsDsIT7Oahj3oh7QCxk6-NNnpM71ZNxhO5ntvHnnpak1UTdEii4TZfn9qgVH2w74p54tBjlHv-C_EYWqTvPku2OczoWq5HZVlJUlSFNUs9Ez81y6k87SSCx12Rc1ClRZt_6zC45-_xPGw3SLInzy3N-8g2wtxgbyNOXdZI2MyoAvugO89xY6sVOcyfu5C5QVUSonFa7tAa-vBbb9Gm7uzTYW0-ra9NxmqCljdPCiTuhcYBJMSOvO4wm5CKEXDklOwYlWMjGck1l4wVyEcWI74ZOMzUS_ZcJ2xCTsYBatLhBeTVU_7bd4NlY"}

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(__dirname) {const path = __webpack_require__(16)
const webpack = __webpack_require__(1)
const markdown = __webpack_require__(17)

const isDebug = process.env.DEBUG

module.exports = (config, { isClient, isDev: _isDev }) => {
  if (!_isDev) {
    //https://webpack.js.org/configuration/devtool/#production
    //nuxt default nosources-source-map,It can be used to map stack traces on the client without exposing all of the source code
    //sentry require source-map
    //todo .vue file source-map fail,dev mode success
    process.env.SOURCE_MAP
      ? (config.devtool = 'source-map')
      : !_isDev && (config.devtool = false)
    //reset uglifyjs config
    config.plugins = config.plugins.filter(
      plugin => plugin.constructor.name !== 'UglifyJsPlugin'
    )
    const PreloadWebpackPlugin = __webpack_require__(21)
    config.plugins.push(
      // new PreloadWebpackPlugin({
      //   include: ['play-help']
      // }),
      new webpack.optimize.UglifyJsPlugin({
        extractComments: {
          filename: 'LICENSES'
        },
        compress: {
          warnings: false,
          drop_console: isDebug,
          drop_debugger: isDebug
        },
        sourceMap: true,
        //todo view version is version:v1.0.0-beta.2 ? webpack require update https://github.com/webpack-contrib/uglifyjs-webpack-plugin/releases
        parallel: true
      })
    )

    if (process.env.npm_config_monitor) {
      config.plugins.push(
        new (__webpack_require__(22))({
          target: '../.nuxt/monitor/stats.json',
          launch: true // -> default 'false'
        })
      )
    }
  } else {
    config.module.rules.push({
      test: /\.json$/i,
      include: path.resolve(__dirname, '../assets/config'),
      //webpack not reference assets/config
      use: ['file-loader?name=config/[name].[ext]']
    })
  }
  //Module build failed: Error: Couldn't find preset "stage-2" relative to directory "D:\\Dev\\alpha-front\\node_modules\\vue-data-tables"
  // config.module.rules.push({
  //   test: /(vue-data-tables.src).*?js$/,
  //   loader: 'babel-loader'
  // })

  config.module.rules.push(markdown)
}
/* WEBPACK VAR INJECTION */}.call(exports, "build"))

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

const slugify = __webpack_require__(18).slugify

module.exports = {
  test: /\.md$/,
  loader: 'vue-markdown-loader',
  options: {
    preprocess: function(markdownIt, source) {
      return source.replace(/img/g,'/.nuxt/dist/img/docs')
    },
    use:[
      [__webpack_require__(19), {
        level: 2,
        slugify,
        permalink: true,
        permalinkBefore: true,
        permalinkClass:'anchor',
        permalinkSymbol:'<svg aria-hidden="true" class="octicon octicon-link" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg>'
      }],
      __webpack_require__(20)
    ]
  }
}

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = require("transliteration");

/***/ }),
/* 19 */
/***/ (function(module, exports) {

module.exports = require("markdown-it-anchor");

/***/ }),
/* 20 */
/***/ (function(module, exports) {

module.exports = require("markdown-it-attrs");

/***/ }),
/* 21 */
/***/ (function(module, exports) {

module.exports = require("preload-webpack-plugin");

/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = require("webpack-monitor");

/***/ }),
/* 23 */
/***/ (function(module, exports) {

module.exports = {
  middleware: ['logout'],
  linkExactActiveClass: 'active',
  extendRoutes (routes, resolve) {
    // !isDev && _.remove(routes,_ => _.name === 'login-test')
    // function makeDefault(router) {
    //   const firstRouter = router.children[0]
    //   const children = firstRouter.children
    //   const component = children ? children[0].component : firstRouter.component
    //   router.children.unshift({ path: '', component })
    //   delete router.name
    //   if (children) makeDefault(firstRouter)
    // }
    // makeDefault(routes.find(_ => _.name === 'admin'))

    // routes.find(_ => _.name === 'admin').children.forEach(router => {
    //   if(router.children) {
    //     const component = router.children[0].component
    //     router.children.unshift({ path: '', component })
    //     delete router.name
    //   }
    // })

    return routes

  }
}

/***/ }),
/* 24 */
/***/ (function(module, exports) {

module.exports = require("opn");

/***/ })
/******/ ]);
//# sourceMappingURL=caishi.map