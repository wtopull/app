<template>
  <nuxt/>
</template>

