components/reposal/Options.vue 无奖金组调节，移除该组件

components/lotto/Options.vue 冗余

components/reposal/11x5/Integrate.vue 和ssc的重复

components/reposal/pk10/Integrate.vue 2个5列 ul li合并 同1to10.vue