- [信用玩法 问路](#xin-yong-wan-fa-wen-lu)
- [中奖提示](#zhong-jiang-ti-shi)
- [在线客服](#zai-xian-ke-fu)
- [提现 相关说明](#ti-xian-xiang-guan-shuo-ming)

## 信用玩法 问路 🚀
![](img/问路.jpg)

负责人:rex

## 中奖提示
> 目前只有开奖号码更新提示

等socket 排期

## 在线客服
（免登录可用？）
![](img/在线客服.jpg)

等待确认53客服

预计下周三出


## 提现 相关说明
![](img/提现相关说明.jpg)

提现账户详情返回字段



